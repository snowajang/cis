using Microsoft.Extensions.Caching.Distributed;

namespace cis.Services
{
    public interface IUserSessionStore
    {
        Task SetSessionAsync(string userId, string sessionId, TimeSpan expiry, CancellationToken cancellationToken = default);
        Task<string?> GetSessionAsync(string userId, CancellationToken cancellationToken = default);
        Task RemoveSessionAsync(string userId, CancellationToken cancellationToken = default);
    }

    public class UserSessionStore : IUserSessionStore
    {
        private readonly IDistributedCache _cache;
        private readonly IConfiguration _configuration;

        public UserSessionStore(IDistributedCache cache, IConfiguration configuration)
        {
            _cache = cache;
            _configuration = configuration;
        }

        private string BuildKey(string userId)
        {
            var prefix = _configuration["Redis:InstanceName"] ?? "cis:";
            return $"{prefix}auth:session:{userId}";
        }

        public async Task SetSessionAsync(string userId, string sessionId, TimeSpan expiry, CancellationToken cancellationToken = default)
        {
            var options = new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = expiry
            };

            await _cache.SetStringAsync(BuildKey(userId), sessionId, options, cancellationToken);
        }

        public async Task<string?> GetSessionAsync(string userId, CancellationToken cancellationToken = default)
        {
            return await _cache.GetStringAsync(BuildKey(userId), cancellationToken);
        }

        public async Task RemoveSessionAsync(string userId, CancellationToken cancellationToken = default)
        {
            await _cache.RemoveAsync(BuildKey(userId), cancellationToken);
        }
    }
}
