using System.Diagnostics;
using System.Security.Claims;
using cis.Services;
using CISApps.Models;
using CISApps.Models.Home;
using CISApps.Models.Rest;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace cis.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IUserSessionStore _sessionStore;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IUserSessionStore sessionStore, IConfiguration configuration)
        {
            _logger = logger;
            _sessionStore = sessionStore;
            _configuration = configuration;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index(int logout = 0)
        {
            if (logout == 1)
            {
                await ClearCurrentSessionAsync();
            }

            if (User?.Identity?.IsAuthenticated ?? false)
            {
                return RedirectToAction("Index", "User");
            }

            return View(new LoginThaiD());
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(LoginThaiD login)
        {
            return await SignInByThaiDAsync(login);
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Thaid(LoginThaiD login)
        {
            return await SignInByThaiDAsync(login);
        }

        [AllowAnonymous]
        public IActionResult Privacy()
        {
            return View();
        }

        [AllowAnonymous]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await ClearCurrentSessionAsync();
            return RedirectToAction("Index", "Home");
        }

        private async Task<IActionResult> SignInByThaiDAsync(LoginThaiD login)
        {
            try
            {
                if (login == null)
                {
                    login = new LoginThaiD
                    {
                        error = "ไม่ได้รับการตอบกลับจากระบบ ThaID"
                    };
                    return View("Index", login);
                }

                string token = string.Empty;
                try
                {
                    if (!string.IsNullOrEmpty(login.error))
                    {
                        return View("Index", login);
                    }

                    long ipid = long.Parse(login.pid);
                    var api = new Api("https://web-app.bora.dopa.go.th/meetrens");
                    var response = await api.POST(
                        "/api/center/login/confirm",
                        new { loginType = 2, officeID = 333, accessToken = login.access_token.Trim(), personalID = ipid }
                    );

                    var data = await response.Content.ReadAsStringAsync();
                    var json = data.ToObjectJson<ResponseLogin>();
                    if (response.StatusCode != System.Net.HttpStatusCode.Created)
                    {
                        login.error = json?.errorNumber > 0 ? (json?.errorMessage ?? string.Empty) : "พบปัญหาเชื่อมต่อระบบ";
                        return View("Index", login);
                    }

                    token = json?.token ?? string.Empty;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "home-index-login-confirm");
                    throw;
                }

                var sessionId = Guid.NewGuid().ToString("N");
                var expiresMinutes = _configuration.GetValue<int?>("Authentication:CookieExpireMinutes") ?? 20;
                var expiresAt = DateTime.UtcNow.AddMinutes(expiresMinutes);

                var identity = new ClaimsIdentity(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    ClaimTypes.Name,
                    ClaimTypes.Role);

                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, login.pid));
                identity.AddClaim(new Claim(ClaimTypes.Name, login.name ?? string.Empty));
                identity.AddClaim(new Claim("lktoken", token));
                identity.AddClaim(new Claim("session_id", sessionId));

                var principal = new ClaimsPrincipal(identity);

                await _sessionStore.SetSessionAsync(login.pid, sessionId, TimeSpan.FromMinutes(expiresMinutes), HttpContext.RequestAborted);

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    principal,
                    new AuthenticationProperties
                    {
                        IsPersistent = true,
                        AllowRefresh = false,
                        ExpiresUtc = expiresAt
                    });

                return RedirectToAction("Index", "User");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "home-index");
                throw;
            }
        }

        private async Task ClearCurrentSessionAsync()
        {
            var pid = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrWhiteSpace(pid))
            {
                await _sessionStore.RemoveSessionAsync(pid, HttpContext.RequestAborted);
            }

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        }
    }
}
