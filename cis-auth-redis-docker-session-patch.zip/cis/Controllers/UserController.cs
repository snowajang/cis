﻿using Microsoft.AspNetCore.Mvc;

namespace cis.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
